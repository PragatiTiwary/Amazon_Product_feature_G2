package Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import utils.BrowserManager;

public class StepDefinition {
    private WebDriver driver;
    public StepDefinition(BrowserManager browserManager){
        this.driver = browserManager.getDriver();
    }


    @Given(" the user navigates to the home Page.")
    public void the_user_navigates_to_the_home_page() {
         driver.get("https://www.amazon.in/");

    }
    @When(" the user open amazon website.")
    public void the_user_open_amazon_website() {
        


         }

    @Then(" the user should see All Category.")
    public void the_user_should_see_all_category() {

        }
}